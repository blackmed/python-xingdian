

# md5(), sha1(), sha224(), sha256(), sha384(), and sha512()

import hashlib
# 1.创建一个hash对象
h = hashlib.md5()
# 2.填充要加密的数据
passwordstr = '123456'
h.update(bytes(passwordstr, encoding='utf-8'))
# 3.获取加密结果
pawd_result = h.hexdigest()
print(pawd_result)

